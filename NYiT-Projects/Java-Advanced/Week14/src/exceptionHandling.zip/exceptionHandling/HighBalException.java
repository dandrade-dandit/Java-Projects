package exceptionHandling;

public class HighBalException extends Exception{
		public HighBalException() {
			super("Customer Balance is High");
		}
}
