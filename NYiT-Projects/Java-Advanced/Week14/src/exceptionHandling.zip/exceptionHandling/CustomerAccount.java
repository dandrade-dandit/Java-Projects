package exceptionHandling;

public class CustomerAccount {
	private int accNum;
	private double balance;
	public static double HIGH_BAL_LIMIT = 200000.0;
	public CustomerAccount(int accNum, double balance) throws HighBalException {
		
		this.accNum = accNum;
		this.balance = balance;
		
		if(balance>HIGH_BAL_LIMIT) {
			throw (new HighBalException());
		}
	}
	
	

}
