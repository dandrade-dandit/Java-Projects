package exceptionHandling;

import java.util.InputMismatchException;
import java.util.Scanner;

public class DivisionExceptionNew {

	public static void main(String[] args) {
		int num, den, result;
		
		Scanner input = new Scanner(System.in);
		try {
		System.out.println("Enter the numerator");
		num=input.nextInt();
		System.out.println("Enter the denominator");
		den=input.nextInt();
		result = num/den;
		System.out.println("The result is: " + result);
		}
		
		catch(ArithmeticException e) {
			System.out.println(e.getMessage());
		}
		catch(InputMismatchException e) {
			System.out.println("An input mismatch exception has occured");
			//System.out.println(e.getMessage());
			
		}
		catch(Exception e) {
			System.out.println("An exception has occured");
		}
		finally {
			System.out.println("End of program");
		}
		
	}

}
