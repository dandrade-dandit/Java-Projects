package exceptionHandling;

import java.util.Scanner;

public class DivisionException {

	public static void main(String[] args) {
		int num, den, result;
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the numerator");
		num=input.nextInt();
		System.out.println("Enter the denominator");
		den=input.nextInt();
		if(den==0) {
			System.out.println("The denominator can't be zero");	
		}
		else {
			result = num/den;
			System.out.println("The result is: " + result);
		}
	

	}

}
